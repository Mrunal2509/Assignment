public class Pattern4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=4;i++) {
		for(int s=i;s<4;s++) {
			System.out.print(" ");
		}
		for(int j=1;j<=i;j++) {
			System.out.print("* ");
		}
		System.out.println();
	}
		
			for(int i=1;i<=3;i++) {
				for(int s=0;s<i;s++) {
					System.out.print(" ");
				}
				for(int j=3;j>=i;j--) {
					System.out.print("* ");
				}
				System.out.println();
		}
		

		
		
		

	}

}
