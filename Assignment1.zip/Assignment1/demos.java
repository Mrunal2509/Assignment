public class demos
{
	public static void main(String[] args) {
		
	
		for(int i=3;i<=30;i++)
		{
			if(i==24) {
				continue;
			}
		
		System.out.println(i);
		}
	}	
}